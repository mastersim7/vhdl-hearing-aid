﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComPorts = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lblmessage = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Tx_Button = New System.Windows.Forms.Button
        Me.Datarecieved_textbox = New System.Windows.Forms.RichTextBox
        Me.Label241 = New System.Windows.Forms.Label
        Me.Label242 = New System.Windows.Forms.Label
        Me.Label243 = New System.Windows.Forms.Label
        Me.Label244 = New System.Windows.Forms.Label
        Me.Label245 = New System.Windows.Forms.Label
        Me.Label246 = New System.Windows.Forms.Label
        Me.Label247 = New System.Windows.Forms.Label
        Me.Label248 = New System.Windows.Forms.Label
        Me.Label249 = New System.Windows.Forms.Label
        Me.Label250 = New System.Windows.Forms.Label
        Me.Label251 = New System.Windows.Forms.Label
        Me.Label252 = New System.Windows.Forms.Label
        Me.Label253 = New System.Windows.Forms.Label
        Me.Label254 = New System.Windows.Forms.Label
        Me.Label255 = New System.Windows.Forms.Label
        Me.Label256 = New System.Windows.Forms.Label
        Me.Label257 = New System.Windows.Forms.Label
        Me.Label258 = New System.Windows.Forms.Label
        Me.Label259 = New System.Windows.Forms.Label
        Me.Label260 = New System.Windows.Forms.Label
        Me.Label261 = New System.Windows.Forms.Label
        Me.Label262 = New System.Windows.Forms.Label
        Me.Label263 = New System.Windows.Forms.Label
        Me.Label264 = New System.Windows.Forms.Label
        Me.Label265 = New System.Windows.Forms.Label
        Me.Label266 = New System.Windows.Forms.Label
        Me.Label267 = New System.Windows.Forms.Label
        Me.Label268 = New System.Windows.Forms.Label
        Me.Label269 = New System.Windows.Forms.Label
        Me.Label270 = New System.Windows.Forms.Label
        Me.Label271 = New System.Windows.Forms.Label
        Me.Label272 = New System.Windows.Forms.Label
        Me.Label209 = New System.Windows.Forms.Label
        Me.Label210 = New System.Windows.Forms.Label
        Me.Label211 = New System.Windows.Forms.Label
        Me.Label212 = New System.Windows.Forms.Label
        Me.Label213 = New System.Windows.Forms.Label
        Me.Label214 = New System.Windows.Forms.Label
        Me.Label215 = New System.Windows.Forms.Label
        Me.Label216 = New System.Windows.Forms.Label
        Me.Label217 = New System.Windows.Forms.Label
        Me.Label218 = New System.Windows.Forms.Label
        Me.Label219 = New System.Windows.Forms.Label
        Me.Label220 = New System.Windows.Forms.Label
        Me.Label221 = New System.Windows.Forms.Label
        Me.Label222 = New System.Windows.Forms.Label
        Me.Label223 = New System.Windows.Forms.Label
        Me.Label224 = New System.Windows.Forms.Label
        Me.Label225 = New System.Windows.Forms.Label
        Me.Label226 = New System.Windows.Forms.Label
        Me.Label227 = New System.Windows.Forms.Label
        Me.Label228 = New System.Windows.Forms.Label
        Me.Label229 = New System.Windows.Forms.Label
        Me.Label230 = New System.Windows.Forms.Label
        Me.Label231 = New System.Windows.Forms.Label
        Me.Label232 = New System.Windows.Forms.Label
        Me.Label233 = New System.Windows.Forms.Label
        Me.Label234 = New System.Windows.Forms.Label
        Me.Label235 = New System.Windows.Forms.Label
        Me.Label236 = New System.Windows.Forms.Label
        Me.Label237 = New System.Windows.Forms.Label
        Me.Label238 = New System.Windows.Forms.Label
        Me.Label239 = New System.Windows.Forms.Label
        Me.Label240 = New System.Windows.Forms.Label
        Me.Label177 = New System.Windows.Forms.Label
        Me.Label178 = New System.Windows.Forms.Label
        Me.Label179 = New System.Windows.Forms.Label
        Me.Label180 = New System.Windows.Forms.Label
        Me.Label181 = New System.Windows.Forms.Label
        Me.Label182 = New System.Windows.Forms.Label
        Me.Label183 = New System.Windows.Forms.Label
        Me.Label184 = New System.Windows.Forms.Label
        Me.Label185 = New System.Windows.Forms.Label
        Me.Label186 = New System.Windows.Forms.Label
        Me.Label187 = New System.Windows.Forms.Label
        Me.Label188 = New System.Windows.Forms.Label
        Me.Label189 = New System.Windows.Forms.Label
        Me.Label190 = New System.Windows.Forms.Label
        Me.Label191 = New System.Windows.Forms.Label
        Me.Label192 = New System.Windows.Forms.Label
        Me.Label193 = New System.Windows.Forms.Label
        Me.Label194 = New System.Windows.Forms.Label
        Me.Label195 = New System.Windows.Forms.Label
        Me.Label196 = New System.Windows.Forms.Label
        Me.Label197 = New System.Windows.Forms.Label
        Me.Label198 = New System.Windows.Forms.Label
        Me.Label199 = New System.Windows.Forms.Label
        Me.Label200 = New System.Windows.Forms.Label
        Me.Label201 = New System.Windows.Forms.Label
        Me.Label202 = New System.Windows.Forms.Label
        Me.Label203 = New System.Windows.Forms.Label
        Me.Label204 = New System.Windows.Forms.Label
        Me.Label205 = New System.Windows.Forms.Label
        Me.Label206 = New System.Windows.Forms.Label
        Me.Label207 = New System.Windows.Forms.Label
        Me.Label208 = New System.Windows.Forms.Label
        Me.Label145 = New System.Windows.Forms.Label
        Me.Label146 = New System.Windows.Forms.Label
        Me.Label147 = New System.Windows.Forms.Label
        Me.Label148 = New System.Windows.Forms.Label
        Me.Label149 = New System.Windows.Forms.Label
        Me.Label150 = New System.Windows.Forms.Label
        Me.Label151 = New System.Windows.Forms.Label
        Me.Label152 = New System.Windows.Forms.Label
        Me.Label153 = New System.Windows.Forms.Label
        Me.Label154 = New System.Windows.Forms.Label
        Me.Label155 = New System.Windows.Forms.Label
        Me.Label156 = New System.Windows.Forms.Label
        Me.Label157 = New System.Windows.Forms.Label
        Me.Label158 = New System.Windows.Forms.Label
        Me.Label159 = New System.Windows.Forms.Label
        Me.Label160 = New System.Windows.Forms.Label
        Me.Label161 = New System.Windows.Forms.Label
        Me.Label162 = New System.Windows.Forms.Label
        Me.Label163 = New System.Windows.Forms.Label
        Me.Label164 = New System.Windows.Forms.Label
        Me.Label165 = New System.Windows.Forms.Label
        Me.Label166 = New System.Windows.Forms.Label
        Me.Label167 = New System.Windows.Forms.Label
        Me.Label168 = New System.Windows.Forms.Label
        Me.Label169 = New System.Windows.Forms.Label
        Me.Label170 = New System.Windows.Forms.Label
        Me.Label171 = New System.Windows.Forms.Label
        Me.Label172 = New System.Windows.Forms.Label
        Me.Label173 = New System.Windows.Forms.Label
        Me.Label174 = New System.Windows.Forms.Label
        Me.Label175 = New System.Windows.Forms.Label
        Me.Label176 = New System.Windows.Forms.Label
        Me.Label113 = New System.Windows.Forms.Label
        Me.Label114 = New System.Windows.Forms.Label
        Me.Label115 = New System.Windows.Forms.Label
        Me.Label116 = New System.Windows.Forms.Label
        Me.Label117 = New System.Windows.Forms.Label
        Me.Label118 = New System.Windows.Forms.Label
        Me.Label119 = New System.Windows.Forms.Label
        Me.Label120 = New System.Windows.Forms.Label
        Me.Label121 = New System.Windows.Forms.Label
        Me.Label122 = New System.Windows.Forms.Label
        Me.Label123 = New System.Windows.Forms.Label
        Me.Label124 = New System.Windows.Forms.Label
        Me.Label125 = New System.Windows.Forms.Label
        Me.Label126 = New System.Windows.Forms.Label
        Me.Label127 = New System.Windows.Forms.Label
        Me.Label128 = New System.Windows.Forms.Label
        Me.Label129 = New System.Windows.Forms.Label
        Me.Label130 = New System.Windows.Forms.Label
        Me.Label131 = New System.Windows.Forms.Label
        Me.Label132 = New System.Windows.Forms.Label
        Me.Label133 = New System.Windows.Forms.Label
        Me.Label134 = New System.Windows.Forms.Label
        Me.Label135 = New System.Windows.Forms.Label
        Me.Label136 = New System.Windows.Forms.Label
        Me.Label137 = New System.Windows.Forms.Label
        Me.Label138 = New System.Windows.Forms.Label
        Me.Label139 = New System.Windows.Forms.Label
        Me.Label140 = New System.Windows.Forms.Label
        Me.Label141 = New System.Windows.Forms.Label
        Me.Label142 = New System.Windows.Forms.Label
        Me.Label143 = New System.Windows.Forms.Label
        Me.Label144 = New System.Windows.Forms.Label
        Me.Label81 = New System.Windows.Forms.Label
        Me.Label82 = New System.Windows.Forms.Label
        Me.Label83 = New System.Windows.Forms.Label
        Me.Label84 = New System.Windows.Forms.Label
        Me.Label85 = New System.Windows.Forms.Label
        Me.Label86 = New System.Windows.Forms.Label
        Me.Label87 = New System.Windows.Forms.Label
        Me.Label88 = New System.Windows.Forms.Label
        Me.Label89 = New System.Windows.Forms.Label
        Me.Label90 = New System.Windows.Forms.Label
        Me.Label91 = New System.Windows.Forms.Label
        Me.Label92 = New System.Windows.Forms.Label
        Me.Label93 = New System.Windows.Forms.Label
        Me.Label94 = New System.Windows.Forms.Label
        Me.Label95 = New System.Windows.Forms.Label
        Me.Label96 = New System.Windows.Forms.Label
        Me.Label97 = New System.Windows.Forms.Label
        Me.Label98 = New System.Windows.Forms.Label
        Me.Label99 = New System.Windows.Forms.Label
        Me.Label100 = New System.Windows.Forms.Label
        Me.Label101 = New System.Windows.Forms.Label
        Me.Label102 = New System.Windows.Forms.Label
        Me.Label103 = New System.Windows.Forms.Label
        Me.Label104 = New System.Windows.Forms.Label
        Me.Label105 = New System.Windows.Forms.Label
        Me.Label106 = New System.Windows.Forms.Label
        Me.Label107 = New System.Windows.Forms.Label
        Me.Label108 = New System.Windows.Forms.Label
        Me.Label109 = New System.Windows.Forms.Label
        Me.Label110 = New System.Windows.Forms.Label
        Me.Label111 = New System.Windows.Forms.Label
        Me.Label112 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label60 = New System.Windows.Forms.Label
        Me.Label61 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label65 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.Label67 = New System.Windows.Forms.Label
        Me.Label68 = New System.Windows.Forms.Label
        Me.Label69 = New System.Windows.Forms.Label
        Me.Label70 = New System.Windows.Forms.Label
        Me.Label71 = New System.Windows.Forms.Label
        Me.Label72 = New System.Windows.Forms.Label
        Me.Label73 = New System.Windows.Forms.Label
        Me.Label74 = New System.Windows.Forms.Label
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label76 = New System.Windows.Forms.Label
        Me.Label77 = New System.Windows.Forms.Label
        Me.Label78 = New System.Windows.Forms.Label
        Me.Label79 = New System.Windows.Forms.Label
        Me.Label80 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.TrackBar8 = New System.Windows.Forms.TrackBar
        Me.TrackBar7 = New System.Windows.Forms.TrackBar
        Me.TrackBar6 = New System.Windows.Forms.TrackBar
        Me.TrackBar5 = New System.Windows.Forms.TrackBar
        Me.TrackBar4 = New System.Windows.Forms.TrackBar
        Me.TrackBar3 = New System.Windows.Forms.TrackBar
        Me.Label10 = New System.Windows.Forms.Label
        Me.TrackBar2 = New System.Windows.Forms.TrackBar
        Me.Label9 = New System.Windows.Forms.Label
        Me.TrackBar1 = New System.Windows.Forms.TrackBar
        Me.Close_Button = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ListBox1 = New System.Windows.Forms.ListBox
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(270, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Connect"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComPorts
        '
        Me.ComPorts.DropDownWidth = 80
        Me.ComPorts.FormattingEnabled = True
        Me.ComPorts.Location = New System.Drawing.Point(125, 24)
        Me.ComPorts.Name = "ComPorts"
        Me.ComPorts.Size = New System.Drawing.Size(121, 21)
        Me.ComPorts.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Available COM Ports"
        '
        'Lblmessage
        '
        Me.Lblmessage.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Lblmessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lblmessage.Location = New System.Drawing.Point(12, 51)
        Me.Lblmessage.Name = "Lblmessage"
        Me.Lblmessage.Size = New System.Drawing.Size(234, 23)
        Me.Lblmessage.TabIndex = 5
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(270, 51)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Disconnect"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Tx_Button
        '
        Me.Tx_Button.Location = New System.Drawing.Point(270, 425)
        Me.Tx_Button.Name = "Tx_Button"
        Me.Tx_Button.Size = New System.Drawing.Size(75, 23)
        Me.Tx_Button.TabIndex = 7
        Me.Tx_Button.Text = "Tx"
        Me.Tx_Button.UseVisualStyleBackColor = True
        '
        'Datarecieved_textbox
        '
        Me.Datarecieved_textbox.Location = New System.Drawing.Point(12, 100)
        Me.Datarecieved_textbox.Name = "Datarecieved_textbox"
        Me.Datarecieved_textbox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.Datarecieved_textbox.Size = New System.Drawing.Size(333, 168)
        Me.Datarecieved_textbox.TabIndex = 8
        Me.Datarecieved_textbox.Text = ""
        '
        'Label241
        '
        Me.Label241.AutoSize = True
        Me.Label241.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label241.Location = New System.Drawing.Point(1082, 31)
        Me.Label241.Name = "Label241"
        Me.Label241.Size = New System.Drawing.Size(13, 10)
        Me.Label241.TabIndex = 584
        Me.Label241.Text = "32"
        '
        'Label242
        '
        Me.Label242.AutoSize = True
        Me.Label242.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label242.Location = New System.Drawing.Point(1082, 43)
        Me.Label242.Name = "Label242"
        Me.Label242.Size = New System.Drawing.Size(13, 10)
        Me.Label242.TabIndex = 583
        Me.Label242.Text = "31"
        '
        'Label243
        '
        Me.Label243.AutoSize = True
        Me.Label243.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label243.Location = New System.Drawing.Point(1082, 56)
        Me.Label243.Name = "Label243"
        Me.Label243.Size = New System.Drawing.Size(13, 10)
        Me.Label243.TabIndex = 582
        Me.Label243.Text = "30"
        '
        'Label244
        '
        Me.Label244.AutoSize = True
        Me.Label244.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label244.Location = New System.Drawing.Point(1082, 68)
        Me.Label244.Name = "Label244"
        Me.Label244.Size = New System.Drawing.Size(13, 10)
        Me.Label244.TabIndex = 581
        Me.Label244.Text = "29"
        '
        'Label245
        '
        Me.Label245.AutoSize = True
        Me.Label245.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label245.Location = New System.Drawing.Point(1082, 80)
        Me.Label245.Name = "Label245"
        Me.Label245.Size = New System.Drawing.Size(13, 10)
        Me.Label245.TabIndex = 580
        Me.Label245.Text = "28"
        '
        'Label246
        '
        Me.Label246.AutoSize = True
        Me.Label246.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label246.Location = New System.Drawing.Point(1082, 93)
        Me.Label246.Name = "Label246"
        Me.Label246.Size = New System.Drawing.Size(13, 10)
        Me.Label246.TabIndex = 579
        Me.Label246.Text = "27"
        '
        'Label247
        '
        Me.Label247.AutoSize = True
        Me.Label247.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label247.Location = New System.Drawing.Point(1082, 105)
        Me.Label247.Name = "Label247"
        Me.Label247.Size = New System.Drawing.Size(13, 10)
        Me.Label247.TabIndex = 578
        Me.Label247.Text = "26"
        '
        'Label248
        '
        Me.Label248.AutoSize = True
        Me.Label248.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label248.Location = New System.Drawing.Point(1082, 117)
        Me.Label248.Name = "Label248"
        Me.Label248.Size = New System.Drawing.Size(13, 10)
        Me.Label248.TabIndex = 577
        Me.Label248.Text = "25"
        '
        'Label249
        '
        Me.Label249.AutoSize = True
        Me.Label249.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label249.Location = New System.Drawing.Point(1082, 129)
        Me.Label249.Name = "Label249"
        Me.Label249.Size = New System.Drawing.Size(13, 10)
        Me.Label249.TabIndex = 576
        Me.Label249.Text = "24"
        '
        'Label250
        '
        Me.Label250.AutoSize = True
        Me.Label250.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label250.Location = New System.Drawing.Point(1082, 141)
        Me.Label250.Name = "Label250"
        Me.Label250.Size = New System.Drawing.Size(13, 10)
        Me.Label250.TabIndex = 575
        Me.Label250.Text = "23"
        '
        'Label251
        '
        Me.Label251.AutoSize = True
        Me.Label251.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label251.Location = New System.Drawing.Point(1082, 154)
        Me.Label251.Name = "Label251"
        Me.Label251.Size = New System.Drawing.Size(13, 10)
        Me.Label251.TabIndex = 574
        Me.Label251.Text = "22"
        '
        'Label252
        '
        Me.Label252.AutoSize = True
        Me.Label252.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label252.Location = New System.Drawing.Point(1082, 166)
        Me.Label252.Name = "Label252"
        Me.Label252.Size = New System.Drawing.Size(13, 10)
        Me.Label252.TabIndex = 573
        Me.Label252.Text = "21"
        '
        'Label253
        '
        Me.Label253.AutoSize = True
        Me.Label253.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label253.Location = New System.Drawing.Point(1082, 179)
        Me.Label253.Name = "Label253"
        Me.Label253.Size = New System.Drawing.Size(13, 10)
        Me.Label253.TabIndex = 572
        Me.Label253.Text = "20"
        '
        'Label254
        '
        Me.Label254.AutoSize = True
        Me.Label254.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label254.Location = New System.Drawing.Point(1082, 191)
        Me.Label254.Name = "Label254"
        Me.Label254.Size = New System.Drawing.Size(13, 10)
        Me.Label254.TabIndex = 571
        Me.Label254.Text = "19"
        '
        'Label255
        '
        Me.Label255.AutoSize = True
        Me.Label255.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label255.Location = New System.Drawing.Point(1082, 203)
        Me.Label255.Name = "Label255"
        Me.Label255.Size = New System.Drawing.Size(13, 10)
        Me.Label255.TabIndex = 570
        Me.Label255.Text = "18"
        '
        'Label256
        '
        Me.Label256.AutoSize = True
        Me.Label256.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label256.Location = New System.Drawing.Point(1082, 215)
        Me.Label256.Name = "Label256"
        Me.Label256.Size = New System.Drawing.Size(13, 10)
        Me.Label256.TabIndex = 569
        Me.Label256.Text = "17"
        '
        'Label257
        '
        Me.Label257.AutoSize = True
        Me.Label257.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label257.Location = New System.Drawing.Point(1082, 228)
        Me.Label257.Name = "Label257"
        Me.Label257.Size = New System.Drawing.Size(13, 10)
        Me.Label257.TabIndex = 568
        Me.Label257.Text = "16"
        '
        'Label258
        '
        Me.Label258.AutoSize = True
        Me.Label258.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label258.Location = New System.Drawing.Point(1082, 240)
        Me.Label258.Name = "Label258"
        Me.Label258.Size = New System.Drawing.Size(13, 10)
        Me.Label258.TabIndex = 567
        Me.Label258.Text = "15"
        '
        'Label259
        '
        Me.Label259.AutoSize = True
        Me.Label259.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label259.Location = New System.Drawing.Point(1082, 254)
        Me.Label259.Name = "Label259"
        Me.Label259.Size = New System.Drawing.Size(13, 10)
        Me.Label259.TabIndex = 566
        Me.Label259.Text = "14"
        '
        'Label260
        '
        Me.Label260.AutoSize = True
        Me.Label260.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label260.Location = New System.Drawing.Point(1082, 266)
        Me.Label260.Name = "Label260"
        Me.Label260.Size = New System.Drawing.Size(13, 10)
        Me.Label260.TabIndex = 565
        Me.Label260.Text = "13"
        '
        'Label261
        '
        Me.Label261.AutoSize = True
        Me.Label261.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label261.Location = New System.Drawing.Point(1082, 278)
        Me.Label261.Name = "Label261"
        Me.Label261.Size = New System.Drawing.Size(13, 10)
        Me.Label261.TabIndex = 564
        Me.Label261.Text = "12"
        '
        'Label262
        '
        Me.Label262.AutoSize = True
        Me.Label262.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label262.Location = New System.Drawing.Point(1082, 289)
        Me.Label262.Name = "Label262"
        Me.Label262.Size = New System.Drawing.Size(13, 10)
        Me.Label262.TabIndex = 563
        Me.Label262.Text = "11"
        '
        'Label263
        '
        Me.Label263.AutoSize = True
        Me.Label263.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label263.Location = New System.Drawing.Point(1082, 301)
        Me.Label263.Name = "Label263"
        Me.Label263.Size = New System.Drawing.Size(13, 10)
        Me.Label263.TabIndex = 562
        Me.Label263.Text = "10"
        '
        'Label264
        '
        Me.Label264.AutoSize = True
        Me.Label264.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label264.Location = New System.Drawing.Point(1084, 313)
        Me.Label264.Name = "Label264"
        Me.Label264.Size = New System.Drawing.Size(9, 10)
        Me.Label264.TabIndex = 561
        Me.Label264.Text = "9"
        '
        'Label265
        '
        Me.Label265.AutoSize = True
        Me.Label265.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label265.Location = New System.Drawing.Point(1084, 325)
        Me.Label265.Name = "Label265"
        Me.Label265.Size = New System.Drawing.Size(9, 10)
        Me.Label265.TabIndex = 560
        Me.Label265.Text = "8"
        '
        'Label266
        '
        Me.Label266.AutoSize = True
        Me.Label266.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label266.Location = New System.Drawing.Point(1084, 337)
        Me.Label266.Name = "Label266"
        Me.Label266.Size = New System.Drawing.Size(9, 10)
        Me.Label266.TabIndex = 559
        Me.Label266.Text = "7"
        '
        'Label267
        '
        Me.Label267.AutoSize = True
        Me.Label267.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label267.Location = New System.Drawing.Point(1084, 350)
        Me.Label267.Name = "Label267"
        Me.Label267.Size = New System.Drawing.Size(9, 10)
        Me.Label267.TabIndex = 558
        Me.Label267.Text = "6"
        '
        'Label268
        '
        Me.Label268.AutoSize = True
        Me.Label268.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label268.Location = New System.Drawing.Point(1084, 363)
        Me.Label268.Name = "Label268"
        Me.Label268.Size = New System.Drawing.Size(9, 10)
        Me.Label268.TabIndex = 557
        Me.Label268.Text = "5"
        '
        'Label269
        '
        Me.Label269.AutoSize = True
        Me.Label269.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label269.Location = New System.Drawing.Point(1084, 375)
        Me.Label269.Name = "Label269"
        Me.Label269.Size = New System.Drawing.Size(9, 10)
        Me.Label269.TabIndex = 556
        Me.Label269.Text = "4"
        '
        'Label270
        '
        Me.Label270.AutoSize = True
        Me.Label270.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label270.Location = New System.Drawing.Point(1084, 387)
        Me.Label270.Name = "Label270"
        Me.Label270.Size = New System.Drawing.Size(9, 10)
        Me.Label270.TabIndex = 555
        Me.Label270.Text = "3"
        '
        'Label271
        '
        Me.Label271.AutoSize = True
        Me.Label271.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label271.Location = New System.Drawing.Point(1084, 399)
        Me.Label271.Name = "Label271"
        Me.Label271.Size = New System.Drawing.Size(9, 10)
        Me.Label271.TabIndex = 554
        Me.Label271.Text = "2"
        '
        'Label272
        '
        Me.Label272.AutoSize = True
        Me.Label272.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label272.Location = New System.Drawing.Point(1084, 411)
        Me.Label272.Name = "Label272"
        Me.Label272.Size = New System.Drawing.Size(9, 10)
        Me.Label272.TabIndex = 553
        Me.Label272.Text = "1"
        '
        'Label209
        '
        Me.Label209.AutoSize = True
        Me.Label209.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label209.Location = New System.Drawing.Point(982, 31)
        Me.Label209.Name = "Label209"
        Me.Label209.Size = New System.Drawing.Size(13, 10)
        Me.Label209.TabIndex = 552
        Me.Label209.Text = "32"
        '
        'Label210
        '
        Me.Label210.AutoSize = True
        Me.Label210.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label210.Location = New System.Drawing.Point(982, 43)
        Me.Label210.Name = "Label210"
        Me.Label210.Size = New System.Drawing.Size(13, 10)
        Me.Label210.TabIndex = 551
        Me.Label210.Text = "31"
        '
        'Label211
        '
        Me.Label211.AutoSize = True
        Me.Label211.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label211.Location = New System.Drawing.Point(982, 56)
        Me.Label211.Name = "Label211"
        Me.Label211.Size = New System.Drawing.Size(13, 10)
        Me.Label211.TabIndex = 550
        Me.Label211.Text = "30"
        '
        'Label212
        '
        Me.Label212.AutoSize = True
        Me.Label212.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label212.Location = New System.Drawing.Point(982, 68)
        Me.Label212.Name = "Label212"
        Me.Label212.Size = New System.Drawing.Size(13, 10)
        Me.Label212.TabIndex = 549
        Me.Label212.Text = "29"
        '
        'Label213
        '
        Me.Label213.AutoSize = True
        Me.Label213.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label213.Location = New System.Drawing.Point(982, 80)
        Me.Label213.Name = "Label213"
        Me.Label213.Size = New System.Drawing.Size(13, 10)
        Me.Label213.TabIndex = 548
        Me.Label213.Text = "28"
        '
        'Label214
        '
        Me.Label214.AutoSize = True
        Me.Label214.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label214.Location = New System.Drawing.Point(982, 93)
        Me.Label214.Name = "Label214"
        Me.Label214.Size = New System.Drawing.Size(13, 10)
        Me.Label214.TabIndex = 547
        Me.Label214.Text = "27"
        '
        'Label215
        '
        Me.Label215.AutoSize = True
        Me.Label215.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label215.Location = New System.Drawing.Point(982, 105)
        Me.Label215.Name = "Label215"
        Me.Label215.Size = New System.Drawing.Size(13, 10)
        Me.Label215.TabIndex = 546
        Me.Label215.Text = "26"
        '
        'Label216
        '
        Me.Label216.AutoSize = True
        Me.Label216.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label216.Location = New System.Drawing.Point(982, 117)
        Me.Label216.Name = "Label216"
        Me.Label216.Size = New System.Drawing.Size(13, 10)
        Me.Label216.TabIndex = 545
        Me.Label216.Text = "25"
        '
        'Label217
        '
        Me.Label217.AutoSize = True
        Me.Label217.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label217.Location = New System.Drawing.Point(982, 129)
        Me.Label217.Name = "Label217"
        Me.Label217.Size = New System.Drawing.Size(13, 10)
        Me.Label217.TabIndex = 544
        Me.Label217.Text = "24"
        '
        'Label218
        '
        Me.Label218.AutoSize = True
        Me.Label218.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label218.Location = New System.Drawing.Point(982, 141)
        Me.Label218.Name = "Label218"
        Me.Label218.Size = New System.Drawing.Size(13, 10)
        Me.Label218.TabIndex = 543
        Me.Label218.Text = "23"
        '
        'Label219
        '
        Me.Label219.AutoSize = True
        Me.Label219.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label219.Location = New System.Drawing.Point(982, 154)
        Me.Label219.Name = "Label219"
        Me.Label219.Size = New System.Drawing.Size(13, 10)
        Me.Label219.TabIndex = 542
        Me.Label219.Text = "22"
        '
        'Label220
        '
        Me.Label220.AutoSize = True
        Me.Label220.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label220.Location = New System.Drawing.Point(982, 166)
        Me.Label220.Name = "Label220"
        Me.Label220.Size = New System.Drawing.Size(13, 10)
        Me.Label220.TabIndex = 541
        Me.Label220.Text = "21"
        '
        'Label221
        '
        Me.Label221.AutoSize = True
        Me.Label221.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label221.Location = New System.Drawing.Point(982, 179)
        Me.Label221.Name = "Label221"
        Me.Label221.Size = New System.Drawing.Size(13, 10)
        Me.Label221.TabIndex = 540
        Me.Label221.Text = "20"
        '
        'Label222
        '
        Me.Label222.AutoSize = True
        Me.Label222.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label222.Location = New System.Drawing.Point(982, 191)
        Me.Label222.Name = "Label222"
        Me.Label222.Size = New System.Drawing.Size(13, 10)
        Me.Label222.TabIndex = 539
        Me.Label222.Text = "19"
        '
        'Label223
        '
        Me.Label223.AutoSize = True
        Me.Label223.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label223.Location = New System.Drawing.Point(982, 203)
        Me.Label223.Name = "Label223"
        Me.Label223.Size = New System.Drawing.Size(13, 10)
        Me.Label223.TabIndex = 538
        Me.Label223.Text = "18"
        '
        'Label224
        '
        Me.Label224.AutoSize = True
        Me.Label224.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label224.Location = New System.Drawing.Point(982, 215)
        Me.Label224.Name = "Label224"
        Me.Label224.Size = New System.Drawing.Size(13, 10)
        Me.Label224.TabIndex = 537
        Me.Label224.Text = "17"
        '
        'Label225
        '
        Me.Label225.AutoSize = True
        Me.Label225.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label225.Location = New System.Drawing.Point(982, 228)
        Me.Label225.Name = "Label225"
        Me.Label225.Size = New System.Drawing.Size(13, 10)
        Me.Label225.TabIndex = 536
        Me.Label225.Text = "16"
        '
        'Label226
        '
        Me.Label226.AutoSize = True
        Me.Label226.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label226.Location = New System.Drawing.Point(982, 240)
        Me.Label226.Name = "Label226"
        Me.Label226.Size = New System.Drawing.Size(13, 10)
        Me.Label226.TabIndex = 535
        Me.Label226.Text = "15"
        '
        'Label227
        '
        Me.Label227.AutoSize = True
        Me.Label227.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label227.Location = New System.Drawing.Point(982, 254)
        Me.Label227.Name = "Label227"
        Me.Label227.Size = New System.Drawing.Size(13, 10)
        Me.Label227.TabIndex = 534
        Me.Label227.Text = "14"
        '
        'Label228
        '
        Me.Label228.AutoSize = True
        Me.Label228.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label228.Location = New System.Drawing.Point(982, 266)
        Me.Label228.Name = "Label228"
        Me.Label228.Size = New System.Drawing.Size(13, 10)
        Me.Label228.TabIndex = 533
        Me.Label228.Text = "13"
        '
        'Label229
        '
        Me.Label229.AutoSize = True
        Me.Label229.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label229.Location = New System.Drawing.Point(982, 278)
        Me.Label229.Name = "Label229"
        Me.Label229.Size = New System.Drawing.Size(13, 10)
        Me.Label229.TabIndex = 532
        Me.Label229.Text = "12"
        '
        'Label230
        '
        Me.Label230.AutoSize = True
        Me.Label230.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label230.Location = New System.Drawing.Point(982, 289)
        Me.Label230.Name = "Label230"
        Me.Label230.Size = New System.Drawing.Size(13, 10)
        Me.Label230.TabIndex = 531
        Me.Label230.Text = "11"
        '
        'Label231
        '
        Me.Label231.AutoSize = True
        Me.Label231.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label231.Location = New System.Drawing.Point(982, 301)
        Me.Label231.Name = "Label231"
        Me.Label231.Size = New System.Drawing.Size(13, 10)
        Me.Label231.TabIndex = 530
        Me.Label231.Text = "10"
        '
        'Label232
        '
        Me.Label232.AutoSize = True
        Me.Label232.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label232.Location = New System.Drawing.Point(984, 313)
        Me.Label232.Name = "Label232"
        Me.Label232.Size = New System.Drawing.Size(9, 10)
        Me.Label232.TabIndex = 529
        Me.Label232.Text = "9"
        '
        'Label233
        '
        Me.Label233.AutoSize = True
        Me.Label233.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label233.Location = New System.Drawing.Point(984, 325)
        Me.Label233.Name = "Label233"
        Me.Label233.Size = New System.Drawing.Size(9, 10)
        Me.Label233.TabIndex = 528
        Me.Label233.Text = "8"
        '
        'Label234
        '
        Me.Label234.AutoSize = True
        Me.Label234.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label234.Location = New System.Drawing.Point(984, 337)
        Me.Label234.Name = "Label234"
        Me.Label234.Size = New System.Drawing.Size(9, 10)
        Me.Label234.TabIndex = 527
        Me.Label234.Text = "7"
        '
        'Label235
        '
        Me.Label235.AutoSize = True
        Me.Label235.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label235.Location = New System.Drawing.Point(984, 350)
        Me.Label235.Name = "Label235"
        Me.Label235.Size = New System.Drawing.Size(9, 10)
        Me.Label235.TabIndex = 526
        Me.Label235.Text = "6"
        '
        'Label236
        '
        Me.Label236.AutoSize = True
        Me.Label236.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label236.Location = New System.Drawing.Point(984, 363)
        Me.Label236.Name = "Label236"
        Me.Label236.Size = New System.Drawing.Size(9, 10)
        Me.Label236.TabIndex = 525
        Me.Label236.Text = "5"
        '
        'Label237
        '
        Me.Label237.AutoSize = True
        Me.Label237.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label237.Location = New System.Drawing.Point(984, 375)
        Me.Label237.Name = "Label237"
        Me.Label237.Size = New System.Drawing.Size(9, 10)
        Me.Label237.TabIndex = 524
        Me.Label237.Text = "4"
        '
        'Label238
        '
        Me.Label238.AutoSize = True
        Me.Label238.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label238.Location = New System.Drawing.Point(984, 387)
        Me.Label238.Name = "Label238"
        Me.Label238.Size = New System.Drawing.Size(9, 10)
        Me.Label238.TabIndex = 523
        Me.Label238.Text = "3"
        '
        'Label239
        '
        Me.Label239.AutoSize = True
        Me.Label239.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label239.Location = New System.Drawing.Point(984, 399)
        Me.Label239.Name = "Label239"
        Me.Label239.Size = New System.Drawing.Size(9, 10)
        Me.Label239.TabIndex = 522
        Me.Label239.Text = "2"
        '
        'Label240
        '
        Me.Label240.AutoSize = True
        Me.Label240.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label240.Location = New System.Drawing.Point(984, 411)
        Me.Label240.Name = "Label240"
        Me.Label240.Size = New System.Drawing.Size(9, 10)
        Me.Label240.TabIndex = 521
        Me.Label240.Text = "1"
        '
        'Label177
        '
        Me.Label177.AutoSize = True
        Me.Label177.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label177.Location = New System.Drawing.Point(882, 31)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(13, 10)
        Me.Label177.TabIndex = 520
        Me.Label177.Text = "32"
        '
        'Label178
        '
        Me.Label178.AutoSize = True
        Me.Label178.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label178.Location = New System.Drawing.Point(882, 43)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(13, 10)
        Me.Label178.TabIndex = 519
        Me.Label178.Text = "31"
        '
        'Label179
        '
        Me.Label179.AutoSize = True
        Me.Label179.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label179.Location = New System.Drawing.Point(882, 56)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(13, 10)
        Me.Label179.TabIndex = 518
        Me.Label179.Text = "30"
        '
        'Label180
        '
        Me.Label180.AutoSize = True
        Me.Label180.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label180.Location = New System.Drawing.Point(882, 68)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(13, 10)
        Me.Label180.TabIndex = 517
        Me.Label180.Text = "29"
        '
        'Label181
        '
        Me.Label181.AutoSize = True
        Me.Label181.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label181.Location = New System.Drawing.Point(882, 80)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(13, 10)
        Me.Label181.TabIndex = 516
        Me.Label181.Text = "28"
        '
        'Label182
        '
        Me.Label182.AutoSize = True
        Me.Label182.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label182.Location = New System.Drawing.Point(882, 93)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(13, 10)
        Me.Label182.TabIndex = 515
        Me.Label182.Text = "27"
        '
        'Label183
        '
        Me.Label183.AutoSize = True
        Me.Label183.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label183.Location = New System.Drawing.Point(882, 105)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(13, 10)
        Me.Label183.TabIndex = 514
        Me.Label183.Text = "26"
        '
        'Label184
        '
        Me.Label184.AutoSize = True
        Me.Label184.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label184.Location = New System.Drawing.Point(882, 117)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(13, 10)
        Me.Label184.TabIndex = 513
        Me.Label184.Text = "25"
        '
        'Label185
        '
        Me.Label185.AutoSize = True
        Me.Label185.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label185.Location = New System.Drawing.Point(882, 129)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(13, 10)
        Me.Label185.TabIndex = 512
        Me.Label185.Text = "24"
        '
        'Label186
        '
        Me.Label186.AutoSize = True
        Me.Label186.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label186.Location = New System.Drawing.Point(882, 141)
        Me.Label186.Name = "Label186"
        Me.Label186.Size = New System.Drawing.Size(13, 10)
        Me.Label186.TabIndex = 511
        Me.Label186.Text = "23"
        '
        'Label187
        '
        Me.Label187.AutoSize = True
        Me.Label187.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label187.Location = New System.Drawing.Point(882, 154)
        Me.Label187.Name = "Label187"
        Me.Label187.Size = New System.Drawing.Size(13, 10)
        Me.Label187.TabIndex = 510
        Me.Label187.Text = "22"
        '
        'Label188
        '
        Me.Label188.AutoSize = True
        Me.Label188.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label188.Location = New System.Drawing.Point(882, 166)
        Me.Label188.Name = "Label188"
        Me.Label188.Size = New System.Drawing.Size(13, 10)
        Me.Label188.TabIndex = 509
        Me.Label188.Text = "21"
        '
        'Label189
        '
        Me.Label189.AutoSize = True
        Me.Label189.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label189.Location = New System.Drawing.Point(882, 179)
        Me.Label189.Name = "Label189"
        Me.Label189.Size = New System.Drawing.Size(13, 10)
        Me.Label189.TabIndex = 508
        Me.Label189.Text = "20"
        '
        'Label190
        '
        Me.Label190.AutoSize = True
        Me.Label190.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label190.Location = New System.Drawing.Point(882, 191)
        Me.Label190.Name = "Label190"
        Me.Label190.Size = New System.Drawing.Size(13, 10)
        Me.Label190.TabIndex = 507
        Me.Label190.Text = "19"
        '
        'Label191
        '
        Me.Label191.AutoSize = True
        Me.Label191.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label191.Location = New System.Drawing.Point(882, 203)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(13, 10)
        Me.Label191.TabIndex = 506
        Me.Label191.Text = "18"
        '
        'Label192
        '
        Me.Label192.AutoSize = True
        Me.Label192.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label192.Location = New System.Drawing.Point(882, 215)
        Me.Label192.Name = "Label192"
        Me.Label192.Size = New System.Drawing.Size(13, 10)
        Me.Label192.TabIndex = 505
        Me.Label192.Text = "17"
        '
        'Label193
        '
        Me.Label193.AutoSize = True
        Me.Label193.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label193.Location = New System.Drawing.Point(882, 228)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(13, 10)
        Me.Label193.TabIndex = 504
        Me.Label193.Text = "16"
        '
        'Label194
        '
        Me.Label194.AutoSize = True
        Me.Label194.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label194.Location = New System.Drawing.Point(882, 240)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(13, 10)
        Me.Label194.TabIndex = 503
        Me.Label194.Text = "15"
        '
        'Label195
        '
        Me.Label195.AutoSize = True
        Me.Label195.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label195.Location = New System.Drawing.Point(882, 254)
        Me.Label195.Name = "Label195"
        Me.Label195.Size = New System.Drawing.Size(13, 10)
        Me.Label195.TabIndex = 502
        Me.Label195.Text = "14"
        '
        'Label196
        '
        Me.Label196.AutoSize = True
        Me.Label196.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label196.Location = New System.Drawing.Point(882, 266)
        Me.Label196.Name = "Label196"
        Me.Label196.Size = New System.Drawing.Size(13, 10)
        Me.Label196.TabIndex = 501
        Me.Label196.Text = "13"
        '
        'Label197
        '
        Me.Label197.AutoSize = True
        Me.Label197.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label197.Location = New System.Drawing.Point(882, 278)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(13, 10)
        Me.Label197.TabIndex = 500
        Me.Label197.Text = "12"
        '
        'Label198
        '
        Me.Label198.AutoSize = True
        Me.Label198.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label198.Location = New System.Drawing.Point(882, 289)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(13, 10)
        Me.Label198.TabIndex = 499
        Me.Label198.Text = "11"
        '
        'Label199
        '
        Me.Label199.AutoSize = True
        Me.Label199.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label199.Location = New System.Drawing.Point(882, 301)
        Me.Label199.Name = "Label199"
        Me.Label199.Size = New System.Drawing.Size(13, 10)
        Me.Label199.TabIndex = 498
        Me.Label199.Text = "10"
        '
        'Label200
        '
        Me.Label200.AutoSize = True
        Me.Label200.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label200.Location = New System.Drawing.Point(884, 313)
        Me.Label200.Name = "Label200"
        Me.Label200.Size = New System.Drawing.Size(9, 10)
        Me.Label200.TabIndex = 497
        Me.Label200.Text = "9"
        '
        'Label201
        '
        Me.Label201.AutoSize = True
        Me.Label201.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label201.Location = New System.Drawing.Point(884, 325)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(9, 10)
        Me.Label201.TabIndex = 496
        Me.Label201.Text = "8"
        '
        'Label202
        '
        Me.Label202.AutoSize = True
        Me.Label202.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label202.Location = New System.Drawing.Point(884, 337)
        Me.Label202.Name = "Label202"
        Me.Label202.Size = New System.Drawing.Size(9, 10)
        Me.Label202.TabIndex = 495
        Me.Label202.Text = "7"
        '
        'Label203
        '
        Me.Label203.AutoSize = True
        Me.Label203.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label203.Location = New System.Drawing.Point(884, 350)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(9, 10)
        Me.Label203.TabIndex = 494
        Me.Label203.Text = "6"
        '
        'Label204
        '
        Me.Label204.AutoSize = True
        Me.Label204.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label204.Location = New System.Drawing.Point(884, 363)
        Me.Label204.Name = "Label204"
        Me.Label204.Size = New System.Drawing.Size(9, 10)
        Me.Label204.TabIndex = 493
        Me.Label204.Text = "5"
        '
        'Label205
        '
        Me.Label205.AutoSize = True
        Me.Label205.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label205.Location = New System.Drawing.Point(884, 375)
        Me.Label205.Name = "Label205"
        Me.Label205.Size = New System.Drawing.Size(9, 10)
        Me.Label205.TabIndex = 492
        Me.Label205.Text = "4"
        '
        'Label206
        '
        Me.Label206.AutoSize = True
        Me.Label206.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label206.Location = New System.Drawing.Point(884, 387)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(9, 10)
        Me.Label206.TabIndex = 491
        Me.Label206.Text = "3"
        '
        'Label207
        '
        Me.Label207.AutoSize = True
        Me.Label207.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label207.Location = New System.Drawing.Point(884, 399)
        Me.Label207.Name = "Label207"
        Me.Label207.Size = New System.Drawing.Size(9, 10)
        Me.Label207.TabIndex = 490
        Me.Label207.Text = "2"
        '
        'Label208
        '
        Me.Label208.AutoSize = True
        Me.Label208.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label208.Location = New System.Drawing.Point(884, 411)
        Me.Label208.Name = "Label208"
        Me.Label208.Size = New System.Drawing.Size(9, 10)
        Me.Label208.TabIndex = 489
        Me.Label208.Text = "1"
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label145.Location = New System.Drawing.Point(782, 31)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(13, 10)
        Me.Label145.TabIndex = 488
        Me.Label145.Text = "32"
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label146.Location = New System.Drawing.Point(782, 43)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(13, 10)
        Me.Label146.TabIndex = 487
        Me.Label146.Text = "31"
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label147.Location = New System.Drawing.Point(782, 56)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(13, 10)
        Me.Label147.TabIndex = 486
        Me.Label147.Text = "30"
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label148.Location = New System.Drawing.Point(782, 68)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(13, 10)
        Me.Label148.TabIndex = 485
        Me.Label148.Text = "29"
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label149.Location = New System.Drawing.Point(782, 80)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(13, 10)
        Me.Label149.TabIndex = 484
        Me.Label149.Text = "28"
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label150.Location = New System.Drawing.Point(782, 93)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(13, 10)
        Me.Label150.TabIndex = 483
        Me.Label150.Text = "27"
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label151.Location = New System.Drawing.Point(782, 105)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(13, 10)
        Me.Label151.TabIndex = 482
        Me.Label151.Text = "26"
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label152.Location = New System.Drawing.Point(782, 117)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(13, 10)
        Me.Label152.TabIndex = 481
        Me.Label152.Text = "25"
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label153.Location = New System.Drawing.Point(782, 129)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(13, 10)
        Me.Label153.TabIndex = 480
        Me.Label153.Text = "24"
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label154.Location = New System.Drawing.Point(782, 141)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(13, 10)
        Me.Label154.TabIndex = 479
        Me.Label154.Text = "23"
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label155.Location = New System.Drawing.Point(782, 154)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(13, 10)
        Me.Label155.TabIndex = 478
        Me.Label155.Text = "22"
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label156.Location = New System.Drawing.Point(782, 166)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(13, 10)
        Me.Label156.TabIndex = 477
        Me.Label156.Text = "21"
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label157.Location = New System.Drawing.Point(782, 179)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(13, 10)
        Me.Label157.TabIndex = 476
        Me.Label157.Text = "20"
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label158.Location = New System.Drawing.Point(782, 191)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(13, 10)
        Me.Label158.TabIndex = 475
        Me.Label158.Text = "19"
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label159.Location = New System.Drawing.Point(782, 203)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(13, 10)
        Me.Label159.TabIndex = 474
        Me.Label159.Text = "18"
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label160.Location = New System.Drawing.Point(782, 215)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(13, 10)
        Me.Label160.TabIndex = 473
        Me.Label160.Text = "17"
        '
        'Label161
        '
        Me.Label161.AutoSize = True
        Me.Label161.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label161.Location = New System.Drawing.Point(782, 228)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(13, 10)
        Me.Label161.TabIndex = 472
        Me.Label161.Text = "16"
        '
        'Label162
        '
        Me.Label162.AutoSize = True
        Me.Label162.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label162.Location = New System.Drawing.Point(782, 240)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(13, 10)
        Me.Label162.TabIndex = 471
        Me.Label162.Text = "15"
        '
        'Label163
        '
        Me.Label163.AutoSize = True
        Me.Label163.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label163.Location = New System.Drawing.Point(782, 254)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(13, 10)
        Me.Label163.TabIndex = 470
        Me.Label163.Text = "14"
        '
        'Label164
        '
        Me.Label164.AutoSize = True
        Me.Label164.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label164.Location = New System.Drawing.Point(782, 266)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(13, 10)
        Me.Label164.TabIndex = 469
        Me.Label164.Text = "13"
        '
        'Label165
        '
        Me.Label165.AutoSize = True
        Me.Label165.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label165.Location = New System.Drawing.Point(782, 278)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(13, 10)
        Me.Label165.TabIndex = 468
        Me.Label165.Text = "12"
        '
        'Label166
        '
        Me.Label166.AutoSize = True
        Me.Label166.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label166.Location = New System.Drawing.Point(782, 289)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(13, 10)
        Me.Label166.TabIndex = 467
        Me.Label166.Text = "11"
        '
        'Label167
        '
        Me.Label167.AutoSize = True
        Me.Label167.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label167.Location = New System.Drawing.Point(782, 301)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(13, 10)
        Me.Label167.TabIndex = 466
        Me.Label167.Text = "10"
        '
        'Label168
        '
        Me.Label168.AutoSize = True
        Me.Label168.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label168.Location = New System.Drawing.Point(784, 313)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(9, 10)
        Me.Label168.TabIndex = 465
        Me.Label168.Text = "9"
        '
        'Label169
        '
        Me.Label169.AutoSize = True
        Me.Label169.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label169.Location = New System.Drawing.Point(784, 325)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(9, 10)
        Me.Label169.TabIndex = 464
        Me.Label169.Text = "8"
        '
        'Label170
        '
        Me.Label170.AutoSize = True
        Me.Label170.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label170.Location = New System.Drawing.Point(784, 337)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(9, 10)
        Me.Label170.TabIndex = 463
        Me.Label170.Text = "7"
        '
        'Label171
        '
        Me.Label171.AutoSize = True
        Me.Label171.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label171.Location = New System.Drawing.Point(784, 350)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(9, 10)
        Me.Label171.TabIndex = 462
        Me.Label171.Text = "6"
        '
        'Label172
        '
        Me.Label172.AutoSize = True
        Me.Label172.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label172.Location = New System.Drawing.Point(784, 363)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(9, 10)
        Me.Label172.TabIndex = 461
        Me.Label172.Text = "5"
        '
        'Label173
        '
        Me.Label173.AutoSize = True
        Me.Label173.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label173.Location = New System.Drawing.Point(784, 375)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(9, 10)
        Me.Label173.TabIndex = 460
        Me.Label173.Text = "4"
        '
        'Label174
        '
        Me.Label174.AutoSize = True
        Me.Label174.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label174.Location = New System.Drawing.Point(784, 387)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(9, 10)
        Me.Label174.TabIndex = 459
        Me.Label174.Text = "3"
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label175.Location = New System.Drawing.Point(784, 399)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(9, 10)
        Me.Label175.TabIndex = 458
        Me.Label175.Text = "2"
        '
        'Label176
        '
        Me.Label176.AutoSize = True
        Me.Label176.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label176.Location = New System.Drawing.Point(784, 411)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(9, 10)
        Me.Label176.TabIndex = 457
        Me.Label176.Text = "1"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label113.Location = New System.Drawing.Point(682, 31)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(13, 10)
        Me.Label113.TabIndex = 456
        Me.Label113.Text = "32"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label114.Location = New System.Drawing.Point(682, 43)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(13, 10)
        Me.Label114.TabIndex = 455
        Me.Label114.Text = "31"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label115.Location = New System.Drawing.Point(682, 56)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(13, 10)
        Me.Label115.TabIndex = 454
        Me.Label115.Text = "30"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label116.Location = New System.Drawing.Point(682, 68)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(13, 10)
        Me.Label116.TabIndex = 453
        Me.Label116.Text = "29"
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label117.Location = New System.Drawing.Point(682, 80)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(13, 10)
        Me.Label117.TabIndex = 452
        Me.Label117.Text = "28"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label118.Location = New System.Drawing.Point(682, 93)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(13, 10)
        Me.Label118.TabIndex = 451
        Me.Label118.Text = "27"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label119.Location = New System.Drawing.Point(682, 105)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(13, 10)
        Me.Label119.TabIndex = 450
        Me.Label119.Text = "26"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label120.Location = New System.Drawing.Point(682, 117)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(13, 10)
        Me.Label120.TabIndex = 449
        Me.Label120.Text = "25"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label121.Location = New System.Drawing.Point(682, 129)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(13, 10)
        Me.Label121.TabIndex = 448
        Me.Label121.Text = "24"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label122.Location = New System.Drawing.Point(682, 141)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(13, 10)
        Me.Label122.TabIndex = 447
        Me.Label122.Text = "23"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label123.Location = New System.Drawing.Point(682, 154)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(13, 10)
        Me.Label123.TabIndex = 446
        Me.Label123.Text = "22"
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label124.Location = New System.Drawing.Point(682, 166)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(13, 10)
        Me.Label124.TabIndex = 445
        Me.Label124.Text = "21"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label125.Location = New System.Drawing.Point(682, 179)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(13, 10)
        Me.Label125.TabIndex = 444
        Me.Label125.Text = "20"
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label126.Location = New System.Drawing.Point(682, 191)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(13, 10)
        Me.Label126.TabIndex = 443
        Me.Label126.Text = "19"
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label127.Location = New System.Drawing.Point(682, 203)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(13, 10)
        Me.Label127.TabIndex = 442
        Me.Label127.Text = "18"
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label128.Location = New System.Drawing.Point(682, 215)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(13, 10)
        Me.Label128.TabIndex = 441
        Me.Label128.Text = "17"
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label129.Location = New System.Drawing.Point(682, 228)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(13, 10)
        Me.Label129.TabIndex = 440
        Me.Label129.Text = "16"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label130.Location = New System.Drawing.Point(682, 240)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(13, 10)
        Me.Label130.TabIndex = 439
        Me.Label130.Text = "15"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label131.Location = New System.Drawing.Point(682, 254)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(13, 10)
        Me.Label131.TabIndex = 438
        Me.Label131.Text = "14"
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label132.Location = New System.Drawing.Point(682, 266)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(13, 10)
        Me.Label132.TabIndex = 437
        Me.Label132.Text = "13"
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label133.Location = New System.Drawing.Point(682, 278)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(13, 10)
        Me.Label133.TabIndex = 436
        Me.Label133.Text = "12"
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label134.Location = New System.Drawing.Point(682, 289)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(13, 10)
        Me.Label134.TabIndex = 435
        Me.Label134.Text = "11"
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label135.Location = New System.Drawing.Point(682, 301)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(13, 10)
        Me.Label135.TabIndex = 434
        Me.Label135.Text = "10"
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label136.Location = New System.Drawing.Point(684, 313)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(9, 10)
        Me.Label136.TabIndex = 433
        Me.Label136.Text = "9"
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label137.Location = New System.Drawing.Point(684, 325)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(9, 10)
        Me.Label137.TabIndex = 432
        Me.Label137.Text = "8"
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label138.Location = New System.Drawing.Point(684, 337)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(9, 10)
        Me.Label138.TabIndex = 431
        Me.Label138.Text = "7"
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label139.Location = New System.Drawing.Point(684, 350)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(9, 10)
        Me.Label139.TabIndex = 430
        Me.Label139.Text = "6"
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label140.Location = New System.Drawing.Point(684, 363)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(9, 10)
        Me.Label140.TabIndex = 429
        Me.Label140.Text = "5"
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label141.Location = New System.Drawing.Point(684, 375)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(9, 10)
        Me.Label141.TabIndex = 428
        Me.Label141.Text = "4"
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label142.Location = New System.Drawing.Point(684, 387)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(9, 10)
        Me.Label142.TabIndex = 427
        Me.Label142.Text = "3"
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label143.Location = New System.Drawing.Point(684, 399)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(9, 10)
        Me.Label143.TabIndex = 426
        Me.Label143.Text = "2"
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label144.Location = New System.Drawing.Point(684, 411)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(9, 10)
        Me.Label144.TabIndex = 425
        Me.Label144.Text = "1"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label81.Location = New System.Drawing.Point(582, 31)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(13, 10)
        Me.Label81.TabIndex = 424
        Me.Label81.Text = "32"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label82.Location = New System.Drawing.Point(582, 43)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(13, 10)
        Me.Label82.TabIndex = 423
        Me.Label82.Text = "31"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label83.Location = New System.Drawing.Point(582, 56)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(13, 10)
        Me.Label83.TabIndex = 422
        Me.Label83.Text = "30"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label84.Location = New System.Drawing.Point(582, 68)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(13, 10)
        Me.Label84.TabIndex = 421
        Me.Label84.Text = "29"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label85.Location = New System.Drawing.Point(582, 80)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(13, 10)
        Me.Label85.TabIndex = 420
        Me.Label85.Text = "28"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label86.Location = New System.Drawing.Point(582, 93)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(13, 10)
        Me.Label86.TabIndex = 419
        Me.Label86.Text = "27"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label87.Location = New System.Drawing.Point(582, 105)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(13, 10)
        Me.Label87.TabIndex = 418
        Me.Label87.Text = "26"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label88.Location = New System.Drawing.Point(582, 117)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(13, 10)
        Me.Label88.TabIndex = 417
        Me.Label88.Text = "25"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label89.Location = New System.Drawing.Point(582, 129)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(13, 10)
        Me.Label89.TabIndex = 416
        Me.Label89.Text = "24"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label90.Location = New System.Drawing.Point(582, 141)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(13, 10)
        Me.Label90.TabIndex = 415
        Me.Label90.Text = "23"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label91.Location = New System.Drawing.Point(582, 154)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(13, 10)
        Me.Label91.TabIndex = 414
        Me.Label91.Text = "22"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label92.Location = New System.Drawing.Point(582, 166)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(13, 10)
        Me.Label92.TabIndex = 413
        Me.Label92.Text = "21"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label93.Location = New System.Drawing.Point(582, 179)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(13, 10)
        Me.Label93.TabIndex = 412
        Me.Label93.Text = "20"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label94.Location = New System.Drawing.Point(582, 191)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(13, 10)
        Me.Label94.TabIndex = 411
        Me.Label94.Text = "19"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label95.Location = New System.Drawing.Point(582, 203)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(13, 10)
        Me.Label95.TabIndex = 410
        Me.Label95.Text = "18"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label96.Location = New System.Drawing.Point(582, 215)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(13, 10)
        Me.Label96.TabIndex = 409
        Me.Label96.Text = "17"
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label97.Location = New System.Drawing.Point(582, 228)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(13, 10)
        Me.Label97.TabIndex = 408
        Me.Label97.Text = "16"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label98.Location = New System.Drawing.Point(582, 240)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(13, 10)
        Me.Label98.TabIndex = 407
        Me.Label98.Text = "15"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label99.Location = New System.Drawing.Point(582, 254)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(13, 10)
        Me.Label99.TabIndex = 406
        Me.Label99.Text = "14"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label100.Location = New System.Drawing.Point(582, 266)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(13, 10)
        Me.Label100.TabIndex = 405
        Me.Label100.Text = "13"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label101.Location = New System.Drawing.Point(582, 278)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(13, 10)
        Me.Label101.TabIndex = 404
        Me.Label101.Text = "12"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label102.Location = New System.Drawing.Point(582, 289)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(13, 10)
        Me.Label102.TabIndex = 403
        Me.Label102.Text = "11"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label103.Location = New System.Drawing.Point(582, 301)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(13, 10)
        Me.Label103.TabIndex = 402
        Me.Label103.Text = "10"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label104.Location = New System.Drawing.Point(584, 313)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(9, 10)
        Me.Label104.TabIndex = 401
        Me.Label104.Text = "9"
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label105.Location = New System.Drawing.Point(584, 325)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(9, 10)
        Me.Label105.TabIndex = 400
        Me.Label105.Text = "8"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label106.Location = New System.Drawing.Point(584, 337)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(9, 10)
        Me.Label106.TabIndex = 399
        Me.Label106.Text = "7"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label107.Location = New System.Drawing.Point(584, 350)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(9, 10)
        Me.Label107.TabIndex = 398
        Me.Label107.Text = "6"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label108.Location = New System.Drawing.Point(584, 363)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(9, 10)
        Me.Label108.TabIndex = 397
        Me.Label108.Text = "5"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label109.Location = New System.Drawing.Point(584, 375)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(9, 10)
        Me.Label109.TabIndex = 396
        Me.Label109.Text = "4"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label110.Location = New System.Drawing.Point(584, 387)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(9, 10)
        Me.Label110.TabIndex = 395
        Me.Label110.Text = "3"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label111.Location = New System.Drawing.Point(584, 399)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(9, 10)
        Me.Label111.TabIndex = 394
        Me.Label111.Text = "2"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label112.Location = New System.Drawing.Point(584, 411)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(9, 10)
        Me.Label112.TabIndex = 393
        Me.Label112.Text = "1"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label49.Location = New System.Drawing.Point(482, 31)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(13, 10)
        Me.Label49.TabIndex = 392
        Me.Label49.Text = "32"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label50.Location = New System.Drawing.Point(482, 43)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(13, 10)
        Me.Label50.TabIndex = 391
        Me.Label50.Text = "31"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label51.Location = New System.Drawing.Point(482, 56)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(13, 10)
        Me.Label51.TabIndex = 390
        Me.Label51.Text = "30"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label52.Location = New System.Drawing.Point(482, 68)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(13, 10)
        Me.Label52.TabIndex = 389
        Me.Label52.Text = "29"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label53.Location = New System.Drawing.Point(482, 80)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(13, 10)
        Me.Label53.TabIndex = 388
        Me.Label53.Text = "28"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label54.Location = New System.Drawing.Point(482, 93)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(13, 10)
        Me.Label54.TabIndex = 387
        Me.Label54.Text = "27"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label55.Location = New System.Drawing.Point(482, 105)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(13, 10)
        Me.Label55.TabIndex = 386
        Me.Label55.Text = "26"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label56.Location = New System.Drawing.Point(482, 117)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(13, 10)
        Me.Label56.TabIndex = 385
        Me.Label56.Text = "25"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label57.Location = New System.Drawing.Point(482, 129)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(13, 10)
        Me.Label57.TabIndex = 384
        Me.Label57.Text = "24"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label58.Location = New System.Drawing.Point(482, 141)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(13, 10)
        Me.Label58.TabIndex = 383
        Me.Label58.Text = "23"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label59.Location = New System.Drawing.Point(482, 154)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(13, 10)
        Me.Label59.TabIndex = 382
        Me.Label59.Text = "22"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label60.Location = New System.Drawing.Point(482, 166)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(13, 10)
        Me.Label60.TabIndex = 381
        Me.Label60.Text = "21"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label61.Location = New System.Drawing.Point(482, 179)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(13, 10)
        Me.Label61.TabIndex = 380
        Me.Label61.Text = "20"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label62.Location = New System.Drawing.Point(482, 191)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(13, 10)
        Me.Label62.TabIndex = 379
        Me.Label62.Text = "19"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label63.Location = New System.Drawing.Point(482, 203)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(13, 10)
        Me.Label63.TabIndex = 378
        Me.Label63.Text = "18"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label64.Location = New System.Drawing.Point(482, 215)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(13, 10)
        Me.Label64.TabIndex = 377
        Me.Label64.Text = "17"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label65.Location = New System.Drawing.Point(482, 228)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(13, 10)
        Me.Label65.TabIndex = 376
        Me.Label65.Text = "16"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label66.Location = New System.Drawing.Point(482, 240)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(13, 10)
        Me.Label66.TabIndex = 375
        Me.Label66.Text = "15"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label67.Location = New System.Drawing.Point(482, 254)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(13, 10)
        Me.Label67.TabIndex = 374
        Me.Label67.Text = "14"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label68.Location = New System.Drawing.Point(482, 266)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(13, 10)
        Me.Label68.TabIndex = 373
        Me.Label68.Text = "13"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label69.Location = New System.Drawing.Point(482, 278)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(13, 10)
        Me.Label69.TabIndex = 372
        Me.Label69.Text = "12"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label70.Location = New System.Drawing.Point(482, 289)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(13, 10)
        Me.Label70.TabIndex = 371
        Me.Label70.Text = "11"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label71.Location = New System.Drawing.Point(482, 301)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(13, 10)
        Me.Label71.TabIndex = 370
        Me.Label71.Text = "10"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label72.Location = New System.Drawing.Point(484, 313)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(9, 10)
        Me.Label72.TabIndex = 369
        Me.Label72.Text = "9"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label73.Location = New System.Drawing.Point(484, 325)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(9, 10)
        Me.Label73.TabIndex = 368
        Me.Label73.Text = "8"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label74.Location = New System.Drawing.Point(484, 337)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(9, 10)
        Me.Label74.TabIndex = 367
        Me.Label74.Text = "7"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label75.Location = New System.Drawing.Point(484, 350)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(9, 10)
        Me.Label75.TabIndex = 366
        Me.Label75.Text = "6"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label76.Location = New System.Drawing.Point(484, 363)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(9, 10)
        Me.Label76.TabIndex = 365
        Me.Label76.Text = "5"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label77.Location = New System.Drawing.Point(484, 375)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(9, 10)
        Me.Label77.TabIndex = 364
        Me.Label77.Text = "4"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label78.Location = New System.Drawing.Point(484, 387)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(9, 10)
        Me.Label78.TabIndex = 363
        Me.Label78.Text = "3"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label79.Location = New System.Drawing.Point(484, 399)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(9, 10)
        Me.Label79.TabIndex = 362
        Me.Label79.Text = "2"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label80.Location = New System.Drawing.Point(484, 411)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(9, 10)
        Me.Label80.TabIndex = 361
        Me.Label80.Text = "1"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label48.Location = New System.Drawing.Point(383, 31)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(13, 10)
        Me.Label48.TabIndex = 360
        Me.Label48.Text = "32"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label47.Location = New System.Drawing.Point(383, 43)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(13, 10)
        Me.Label47.TabIndex = 359
        Me.Label47.Text = "31"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label46.Location = New System.Drawing.Point(383, 56)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(13, 10)
        Me.Label46.TabIndex = 358
        Me.Label46.Text = "30"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label45.Location = New System.Drawing.Point(383, 68)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(13, 10)
        Me.Label45.TabIndex = 357
        Me.Label45.Text = "29"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label44.Location = New System.Drawing.Point(383, 80)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(13, 10)
        Me.Label44.TabIndex = 356
        Me.Label44.Text = "28"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label43.Location = New System.Drawing.Point(383, 93)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(13, 10)
        Me.Label43.TabIndex = 355
        Me.Label43.Text = "27"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label42.Location = New System.Drawing.Point(383, 105)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(13, 10)
        Me.Label42.TabIndex = 354
        Me.Label42.Text = "26"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label41.Location = New System.Drawing.Point(383, 117)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(13, 10)
        Me.Label41.TabIndex = 353
        Me.Label41.Text = "25"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label40.Location = New System.Drawing.Point(383, 129)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(13, 10)
        Me.Label40.TabIndex = 352
        Me.Label40.Text = "24"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label39.Location = New System.Drawing.Point(383, 141)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(13, 10)
        Me.Label39.TabIndex = 351
        Me.Label39.Text = "23"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label38.Location = New System.Drawing.Point(383, 154)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(13, 10)
        Me.Label38.TabIndex = 350
        Me.Label38.Text = "22"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label37.Location = New System.Drawing.Point(383, 166)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(13, 10)
        Me.Label37.TabIndex = 349
        Me.Label37.Text = "21"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label36.Location = New System.Drawing.Point(383, 179)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(13, 10)
        Me.Label36.TabIndex = 348
        Me.Label36.Text = "20"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label35.Location = New System.Drawing.Point(383, 191)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(13, 10)
        Me.Label35.TabIndex = 347
        Me.Label35.Text = "19"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label34.Location = New System.Drawing.Point(383, 203)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(13, 10)
        Me.Label34.TabIndex = 346
        Me.Label34.Text = "18"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label33.Location = New System.Drawing.Point(383, 215)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(13, 10)
        Me.Label33.TabIndex = 345
        Me.Label33.Text = "17"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label32.Location = New System.Drawing.Point(383, 228)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(13, 10)
        Me.Label32.TabIndex = 344
        Me.Label32.Text = "16"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label31.Location = New System.Drawing.Point(383, 240)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(13, 10)
        Me.Label31.TabIndex = 343
        Me.Label31.Text = "15"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label30.Location = New System.Drawing.Point(383, 254)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(13, 10)
        Me.Label30.TabIndex = 342
        Me.Label30.Text = "14"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label29.Location = New System.Drawing.Point(383, 266)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(13, 10)
        Me.Label29.TabIndex = 341
        Me.Label29.Text = "13"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label28.Location = New System.Drawing.Point(383, 278)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(13, 10)
        Me.Label28.TabIndex = 340
        Me.Label28.Text = "12"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label27.Location = New System.Drawing.Point(383, 289)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(13, 10)
        Me.Label27.TabIndex = 339
        Me.Label27.Text = "11"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label26.Location = New System.Drawing.Point(383, 301)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(13, 10)
        Me.Label26.TabIndex = 338
        Me.Label26.Text = "10"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label25.Location = New System.Drawing.Point(385, 313)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(9, 10)
        Me.Label25.TabIndex = 337
        Me.Label25.Text = "9"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label24.Location = New System.Drawing.Point(385, 325)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(9, 10)
        Me.Label24.TabIndex = 336
        Me.Label24.Text = "8"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label23.Location = New System.Drawing.Point(385, 337)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(9, 10)
        Me.Label23.TabIndex = 335
        Me.Label23.Text = "7"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label22.Location = New System.Drawing.Point(385, 350)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(9, 10)
        Me.Label22.TabIndex = 334
        Me.Label22.Text = "6"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label21.Location = New System.Drawing.Point(385, 363)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(9, 10)
        Me.Label21.TabIndex = 333
        Me.Label21.Text = "5"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label20.Location = New System.Drawing.Point(385, 375)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(9, 10)
        Me.Label20.TabIndex = 332
        Me.Label20.Text = "4"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label19.Location = New System.Drawing.Point(385, 387)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(9, 10)
        Me.Label19.TabIndex = 331
        Me.Label19.Text = "3"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label18.Location = New System.Drawing.Point(385, 399)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(9, 10)
        Me.Label18.TabIndex = 330
        Me.Label18.Text = "2"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 6.0!)
        Me.Label17.Location = New System.Drawing.Point(385, 411)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(9, 10)
        Me.Label17.TabIndex = 329
        Me.Label17.Text = "1"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(1098, 432)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 13)
        Me.Label16.TabIndex = 328
        Me.Label16.Text = "Band-8"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(998, 430)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 13)
        Me.Label15.TabIndex = 327
        Me.Label15.Text = "Band-7"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(898, 432)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(41, 13)
        Me.Label14.TabIndex = 326
        Me.Label14.Text = "Band-6"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(798, 432)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 13)
        Me.Label13.TabIndex = 325
        Me.Label13.Text = "Band-5"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(698, 432)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 13)
        Me.Label12.TabIndex = 324
        Me.Label12.Text = "Band-4"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(598, 432)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(41, 13)
        Me.Label11.TabIndex = 323
        Me.Label11.Text = "Band-3"
        '
        'TrackBar8
        '
        Me.TrackBar8.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar8.Location = New System.Drawing.Point(1101, 22)
        Me.TrackBar8.Maximum = 32
        Me.TrackBar8.Minimum = 1
        Me.TrackBar8.Name = "TrackBar8"
        Me.TrackBar8.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar8.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar8.TabIndex = 322
        Me.TrackBar8.Value = 1
        '
        'TrackBar7
        '
        Me.TrackBar7.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar7.Location = New System.Drawing.Point(1001, 22)
        Me.TrackBar7.Maximum = 32
        Me.TrackBar7.Minimum = 1
        Me.TrackBar7.Name = "TrackBar7"
        Me.TrackBar7.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar7.Size = New System.Drawing.Size(45, 405)
        Me.TrackBar7.TabIndex = 321
        Me.TrackBar7.Value = 1
        '
        'TrackBar6
        '
        Me.TrackBar6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar6.Location = New System.Drawing.Point(901, 22)
        Me.TrackBar6.Maximum = 32
        Me.TrackBar6.Minimum = 1
        Me.TrackBar6.Name = "TrackBar6"
        Me.TrackBar6.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar6.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar6.TabIndex = 320
        Me.TrackBar6.Value = 1
        '
        'TrackBar5
        '
        Me.TrackBar5.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar5.Location = New System.Drawing.Point(801, 22)
        Me.TrackBar5.Maximum = 32
        Me.TrackBar5.Minimum = 1
        Me.TrackBar5.Name = "TrackBar5"
        Me.TrackBar5.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar5.Size = New System.Drawing.Size(45, 405)
        Me.TrackBar5.TabIndex = 319
        Me.TrackBar5.Value = 1
        '
        'TrackBar4
        '
        Me.TrackBar4.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar4.Location = New System.Drawing.Point(701, 22)
        Me.TrackBar4.Maximum = 32
        Me.TrackBar4.Minimum = 1
        Me.TrackBar4.Name = "TrackBar4"
        Me.TrackBar4.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar4.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar4.TabIndex = 318
        Me.TrackBar4.Value = 1
        '
        'TrackBar3
        '
        Me.TrackBar3.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar3.Location = New System.Drawing.Point(601, 22)
        Me.TrackBar3.Maximum = 32
        Me.TrackBar3.Minimum = 1
        Me.TrackBar3.Name = "TrackBar3"
        Me.TrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar3.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar3.TabIndex = 317
        Me.TrackBar3.Value = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(498, 432)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 13)
        Me.Label10.TabIndex = 316
        Me.Label10.Text = "Band-2"
        '
        'TrackBar2
        '
        Me.TrackBar2.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar2.Location = New System.Drawing.Point(501, 22)
        Me.TrackBar2.Maximum = 32
        Me.TrackBar2.Minimum = 1
        Me.TrackBar2.Name = "TrackBar2"
        Me.TrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar2.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar2.TabIndex = 315
        Me.TrackBar2.Value = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.MenuBar
        Me.Label9.Location = New System.Drawing.Point(398, 432)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 314
        Me.Label9.Text = "Band-1"
        '
        'TrackBar1
        '
        Me.TrackBar1.BackColor = System.Drawing.SystemColors.HotTrack
        Me.TrackBar1.Location = New System.Drawing.Point(401, 22)
        Me.TrackBar1.Maximum = 32
        Me.TrackBar1.Minimum = 1
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar1.Size = New System.Drawing.Size(45, 407)
        Me.TrackBar1.TabIndex = 313
        Me.TrackBar1.Value = 1
        '
        'Close_Button
        '
        Me.Close_Button.Location = New System.Drawing.Point(270, 454)
        Me.Close_Button.Name = "Close_Button"
        Me.Close_Button.Size = New System.Drawing.Size(75, 23)
        Me.Close_Button.TabIndex = 585
        Me.Close_Button.Text = "&Close"
        Me.Close_Button.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(662, 462)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 16)
        Me.Label2.TabIndex = 586
        Me.Label2.Text = "Gain in decibels"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(12, 301)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(333, 95)
        Me.ListBox1.TabIndex = 587
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1169, 489)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Close_Button)
        Me.Controls.Add(Me.Label241)
        Me.Controls.Add(Me.Label242)
        Me.Controls.Add(Me.Label243)
        Me.Controls.Add(Me.Label244)
        Me.Controls.Add(Me.Label245)
        Me.Controls.Add(Me.Label246)
        Me.Controls.Add(Me.Label247)
        Me.Controls.Add(Me.Label248)
        Me.Controls.Add(Me.Label249)
        Me.Controls.Add(Me.Label250)
        Me.Controls.Add(Me.Label251)
        Me.Controls.Add(Me.Label252)
        Me.Controls.Add(Me.Label253)
        Me.Controls.Add(Me.Label254)
        Me.Controls.Add(Me.Label255)
        Me.Controls.Add(Me.Label256)
        Me.Controls.Add(Me.Label257)
        Me.Controls.Add(Me.Label258)
        Me.Controls.Add(Me.Label259)
        Me.Controls.Add(Me.Label260)
        Me.Controls.Add(Me.Label261)
        Me.Controls.Add(Me.Label262)
        Me.Controls.Add(Me.Label263)
        Me.Controls.Add(Me.Label264)
        Me.Controls.Add(Me.Label265)
        Me.Controls.Add(Me.Label266)
        Me.Controls.Add(Me.Label267)
        Me.Controls.Add(Me.Label268)
        Me.Controls.Add(Me.Label269)
        Me.Controls.Add(Me.Label270)
        Me.Controls.Add(Me.Label271)
        Me.Controls.Add(Me.Label272)
        Me.Controls.Add(Me.Label209)
        Me.Controls.Add(Me.Label210)
        Me.Controls.Add(Me.Label211)
        Me.Controls.Add(Me.Label212)
        Me.Controls.Add(Me.Label213)
        Me.Controls.Add(Me.Label214)
        Me.Controls.Add(Me.Label215)
        Me.Controls.Add(Me.Label216)
        Me.Controls.Add(Me.Label217)
        Me.Controls.Add(Me.Label218)
        Me.Controls.Add(Me.Label219)
        Me.Controls.Add(Me.Label220)
        Me.Controls.Add(Me.Label221)
        Me.Controls.Add(Me.Label222)
        Me.Controls.Add(Me.Label223)
        Me.Controls.Add(Me.Label224)
        Me.Controls.Add(Me.Label225)
        Me.Controls.Add(Me.Label226)
        Me.Controls.Add(Me.Label227)
        Me.Controls.Add(Me.Label228)
        Me.Controls.Add(Me.Label229)
        Me.Controls.Add(Me.Label230)
        Me.Controls.Add(Me.Label231)
        Me.Controls.Add(Me.Label232)
        Me.Controls.Add(Me.Label233)
        Me.Controls.Add(Me.Label234)
        Me.Controls.Add(Me.Label235)
        Me.Controls.Add(Me.Label236)
        Me.Controls.Add(Me.Label237)
        Me.Controls.Add(Me.Label238)
        Me.Controls.Add(Me.Label239)
        Me.Controls.Add(Me.Label240)
        Me.Controls.Add(Me.Label177)
        Me.Controls.Add(Me.Label178)
        Me.Controls.Add(Me.Label179)
        Me.Controls.Add(Me.Label180)
        Me.Controls.Add(Me.Label181)
        Me.Controls.Add(Me.Label182)
        Me.Controls.Add(Me.Label183)
        Me.Controls.Add(Me.Label184)
        Me.Controls.Add(Me.Label185)
        Me.Controls.Add(Me.Label186)
        Me.Controls.Add(Me.Label187)
        Me.Controls.Add(Me.Label188)
        Me.Controls.Add(Me.Label189)
        Me.Controls.Add(Me.Label190)
        Me.Controls.Add(Me.Label191)
        Me.Controls.Add(Me.Label192)
        Me.Controls.Add(Me.Label193)
        Me.Controls.Add(Me.Label194)
        Me.Controls.Add(Me.Label195)
        Me.Controls.Add(Me.Label196)
        Me.Controls.Add(Me.Label197)
        Me.Controls.Add(Me.Label198)
        Me.Controls.Add(Me.Label199)
        Me.Controls.Add(Me.Label200)
        Me.Controls.Add(Me.Label201)
        Me.Controls.Add(Me.Label202)
        Me.Controls.Add(Me.Label203)
        Me.Controls.Add(Me.Label204)
        Me.Controls.Add(Me.Label205)
        Me.Controls.Add(Me.Label206)
        Me.Controls.Add(Me.Label207)
        Me.Controls.Add(Me.Label208)
        Me.Controls.Add(Me.Label145)
        Me.Controls.Add(Me.Label146)
        Me.Controls.Add(Me.Label147)
        Me.Controls.Add(Me.Label148)
        Me.Controls.Add(Me.Label149)
        Me.Controls.Add(Me.Label150)
        Me.Controls.Add(Me.Label151)
        Me.Controls.Add(Me.Label152)
        Me.Controls.Add(Me.Label153)
        Me.Controls.Add(Me.Label154)
        Me.Controls.Add(Me.Label155)
        Me.Controls.Add(Me.Label156)
        Me.Controls.Add(Me.Label157)
        Me.Controls.Add(Me.Label158)
        Me.Controls.Add(Me.Label159)
        Me.Controls.Add(Me.Label160)
        Me.Controls.Add(Me.Label161)
        Me.Controls.Add(Me.Label162)
        Me.Controls.Add(Me.Label163)
        Me.Controls.Add(Me.Label164)
        Me.Controls.Add(Me.Label165)
        Me.Controls.Add(Me.Label166)
        Me.Controls.Add(Me.Label167)
        Me.Controls.Add(Me.Label168)
        Me.Controls.Add(Me.Label169)
        Me.Controls.Add(Me.Label170)
        Me.Controls.Add(Me.Label171)
        Me.Controls.Add(Me.Label172)
        Me.Controls.Add(Me.Label173)
        Me.Controls.Add(Me.Label174)
        Me.Controls.Add(Me.Label175)
        Me.Controls.Add(Me.Label176)
        Me.Controls.Add(Me.Label113)
        Me.Controls.Add(Me.Label114)
        Me.Controls.Add(Me.Label115)
        Me.Controls.Add(Me.Label116)
        Me.Controls.Add(Me.Label117)
        Me.Controls.Add(Me.Label118)
        Me.Controls.Add(Me.Label119)
        Me.Controls.Add(Me.Label120)
        Me.Controls.Add(Me.Label121)
        Me.Controls.Add(Me.Label122)
        Me.Controls.Add(Me.Label123)
        Me.Controls.Add(Me.Label124)
        Me.Controls.Add(Me.Label125)
        Me.Controls.Add(Me.Label126)
        Me.Controls.Add(Me.Label127)
        Me.Controls.Add(Me.Label128)
        Me.Controls.Add(Me.Label129)
        Me.Controls.Add(Me.Label130)
        Me.Controls.Add(Me.Label131)
        Me.Controls.Add(Me.Label132)
        Me.Controls.Add(Me.Label133)
        Me.Controls.Add(Me.Label134)
        Me.Controls.Add(Me.Label135)
        Me.Controls.Add(Me.Label136)
        Me.Controls.Add(Me.Label137)
        Me.Controls.Add(Me.Label138)
        Me.Controls.Add(Me.Label139)
        Me.Controls.Add(Me.Label140)
        Me.Controls.Add(Me.Label141)
        Me.Controls.Add(Me.Label142)
        Me.Controls.Add(Me.Label143)
        Me.Controls.Add(Me.Label144)
        Me.Controls.Add(Me.Label81)
        Me.Controls.Add(Me.Label82)
        Me.Controls.Add(Me.Label83)
        Me.Controls.Add(Me.Label84)
        Me.Controls.Add(Me.Label85)
        Me.Controls.Add(Me.Label86)
        Me.Controls.Add(Me.Label87)
        Me.Controls.Add(Me.Label88)
        Me.Controls.Add(Me.Label89)
        Me.Controls.Add(Me.Label90)
        Me.Controls.Add(Me.Label91)
        Me.Controls.Add(Me.Label92)
        Me.Controls.Add(Me.Label93)
        Me.Controls.Add(Me.Label94)
        Me.Controls.Add(Me.Label95)
        Me.Controls.Add(Me.Label96)
        Me.Controls.Add(Me.Label97)
        Me.Controls.Add(Me.Label98)
        Me.Controls.Add(Me.Label99)
        Me.Controls.Add(Me.Label100)
        Me.Controls.Add(Me.Label101)
        Me.Controls.Add(Me.Label102)
        Me.Controls.Add(Me.Label103)
        Me.Controls.Add(Me.Label104)
        Me.Controls.Add(Me.Label105)
        Me.Controls.Add(Me.Label106)
        Me.Controls.Add(Me.Label107)
        Me.Controls.Add(Me.Label108)
        Me.Controls.Add(Me.Label109)
        Me.Controls.Add(Me.Label110)
        Me.Controls.Add(Me.Label111)
        Me.Controls.Add(Me.Label112)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.Label77)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.Label79)
        Me.Controls.Add(Me.Label80)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TrackBar8)
        Me.Controls.Add(Me.TrackBar7)
        Me.Controls.Add(Me.TrackBar6)
        Me.Controls.Add(Me.TrackBar5)
        Me.Controls.Add(Me.TrackBar4)
        Me.Controls.Add(Me.TrackBar3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TrackBar2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TrackBar1)
        Me.Controls.Add(Me.Datarecieved_textbox)
        Me.Controls.Add(Me.Tx_Button)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Lblmessage)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComPorts)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "RS232"
        CType(Me.TrackBar8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComPorts As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lblmessage As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Tx_Button As System.Windows.Forms.Button
    Friend WithEvents Datarecieved_textbox As System.Windows.Forms.RichTextBox
    Friend WithEvents Label241 As System.Windows.Forms.Label
    Friend WithEvents Label242 As System.Windows.Forms.Label
    Friend WithEvents Label243 As System.Windows.Forms.Label
    Friend WithEvents Label244 As System.Windows.Forms.Label
    Friend WithEvents Label245 As System.Windows.Forms.Label
    Friend WithEvents Label246 As System.Windows.Forms.Label
    Friend WithEvents Label247 As System.Windows.Forms.Label
    Friend WithEvents Label248 As System.Windows.Forms.Label
    Friend WithEvents Label249 As System.Windows.Forms.Label
    Friend WithEvents Label250 As System.Windows.Forms.Label
    Friend WithEvents Label251 As System.Windows.Forms.Label
    Friend WithEvents Label252 As System.Windows.Forms.Label
    Friend WithEvents Label253 As System.Windows.Forms.Label
    Friend WithEvents Label254 As System.Windows.Forms.Label
    Friend WithEvents Label255 As System.Windows.Forms.Label
    Friend WithEvents Label256 As System.Windows.Forms.Label
    Friend WithEvents Label257 As System.Windows.Forms.Label
    Friend WithEvents Label258 As System.Windows.Forms.Label
    Friend WithEvents Label259 As System.Windows.Forms.Label
    Friend WithEvents Label260 As System.Windows.Forms.Label
    Friend WithEvents Label261 As System.Windows.Forms.Label
    Friend WithEvents Label262 As System.Windows.Forms.Label
    Friend WithEvents Label263 As System.Windows.Forms.Label
    Friend WithEvents Label264 As System.Windows.Forms.Label
    Friend WithEvents Label265 As System.Windows.Forms.Label
    Friend WithEvents Label266 As System.Windows.Forms.Label
    Friend WithEvents Label267 As System.Windows.Forms.Label
    Friend WithEvents Label268 As System.Windows.Forms.Label
    Friend WithEvents Label269 As System.Windows.Forms.Label
    Friend WithEvents Label270 As System.Windows.Forms.Label
    Friend WithEvents Label271 As System.Windows.Forms.Label
    Friend WithEvents Label272 As System.Windows.Forms.Label
    Friend WithEvents Label209 As System.Windows.Forms.Label
    Friend WithEvents Label210 As System.Windows.Forms.Label
    Friend WithEvents Label211 As System.Windows.Forms.Label
    Friend WithEvents Label212 As System.Windows.Forms.Label
    Friend WithEvents Label213 As System.Windows.Forms.Label
    Friend WithEvents Label214 As System.Windows.Forms.Label
    Friend WithEvents Label215 As System.Windows.Forms.Label
    Friend WithEvents Label216 As System.Windows.Forms.Label
    Friend WithEvents Label217 As System.Windows.Forms.Label
    Friend WithEvents Label218 As System.Windows.Forms.Label
    Friend WithEvents Label219 As System.Windows.Forms.Label
    Friend WithEvents Label220 As System.Windows.Forms.Label
    Friend WithEvents Label221 As System.Windows.Forms.Label
    Friend WithEvents Label222 As System.Windows.Forms.Label
    Friend WithEvents Label223 As System.Windows.Forms.Label
    Friend WithEvents Label224 As System.Windows.Forms.Label
    Friend WithEvents Label225 As System.Windows.Forms.Label
    Friend WithEvents Label226 As System.Windows.Forms.Label
    Friend WithEvents Label227 As System.Windows.Forms.Label
    Friend WithEvents Label228 As System.Windows.Forms.Label
    Friend WithEvents Label229 As System.Windows.Forms.Label
    Friend WithEvents Label230 As System.Windows.Forms.Label
    Friend WithEvents Label231 As System.Windows.Forms.Label
    Friend WithEvents Label232 As System.Windows.Forms.Label
    Friend WithEvents Label233 As System.Windows.Forms.Label
    Friend WithEvents Label234 As System.Windows.Forms.Label
    Friend WithEvents Label235 As System.Windows.Forms.Label
    Friend WithEvents Label236 As System.Windows.Forms.Label
    Friend WithEvents Label237 As System.Windows.Forms.Label
    Friend WithEvents Label238 As System.Windows.Forms.Label
    Friend WithEvents Label239 As System.Windows.Forms.Label
    Friend WithEvents Label240 As System.Windows.Forms.Label
    Friend WithEvents Label177 As System.Windows.Forms.Label
    Friend WithEvents Label178 As System.Windows.Forms.Label
    Friend WithEvents Label179 As System.Windows.Forms.Label
    Friend WithEvents Label180 As System.Windows.Forms.Label
    Friend WithEvents Label181 As System.Windows.Forms.Label
    Friend WithEvents Label182 As System.Windows.Forms.Label
    Friend WithEvents Label183 As System.Windows.Forms.Label
    Friend WithEvents Label184 As System.Windows.Forms.Label
    Friend WithEvents Label185 As System.Windows.Forms.Label
    Friend WithEvents Label186 As System.Windows.Forms.Label
    Friend WithEvents Label187 As System.Windows.Forms.Label
    Friend WithEvents Label188 As System.Windows.Forms.Label
    Friend WithEvents Label189 As System.Windows.Forms.Label
    Friend WithEvents Label190 As System.Windows.Forms.Label
    Friend WithEvents Label191 As System.Windows.Forms.Label
    Friend WithEvents Label192 As System.Windows.Forms.Label
    Friend WithEvents Label193 As System.Windows.Forms.Label
    Friend WithEvents Label194 As System.Windows.Forms.Label
    Friend WithEvents Label195 As System.Windows.Forms.Label
    Friend WithEvents Label196 As System.Windows.Forms.Label
    Friend WithEvents Label197 As System.Windows.Forms.Label
    Friend WithEvents Label198 As System.Windows.Forms.Label
    Friend WithEvents Label199 As System.Windows.Forms.Label
    Friend WithEvents Label200 As System.Windows.Forms.Label
    Friend WithEvents Label201 As System.Windows.Forms.Label
    Friend WithEvents Label202 As System.Windows.Forms.Label
    Friend WithEvents Label203 As System.Windows.Forms.Label
    Friend WithEvents Label204 As System.Windows.Forms.Label
    Friend WithEvents Label205 As System.Windows.Forms.Label
    Friend WithEvents Label206 As System.Windows.Forms.Label
    Friend WithEvents Label207 As System.Windows.Forms.Label
    Friend WithEvents Label208 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label147 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents Label149 As System.Windows.Forms.Label
    Friend WithEvents Label150 As System.Windows.Forms.Label
    Friend WithEvents Label151 As System.Windows.Forms.Label
    Friend WithEvents Label152 As System.Windows.Forms.Label
    Friend WithEvents Label153 As System.Windows.Forms.Label
    Friend WithEvents Label154 As System.Windows.Forms.Label
    Friend WithEvents Label155 As System.Windows.Forms.Label
    Friend WithEvents Label156 As System.Windows.Forms.Label
    Friend WithEvents Label157 As System.Windows.Forms.Label
    Friend WithEvents Label158 As System.Windows.Forms.Label
    Friend WithEvents Label159 As System.Windows.Forms.Label
    Friend WithEvents Label160 As System.Windows.Forms.Label
    Friend WithEvents Label161 As System.Windows.Forms.Label
    Friend WithEvents Label162 As System.Windows.Forms.Label
    Friend WithEvents Label163 As System.Windows.Forms.Label
    Friend WithEvents Label164 As System.Windows.Forms.Label
    Friend WithEvents Label165 As System.Windows.Forms.Label
    Friend WithEvents Label166 As System.Windows.Forms.Label
    Friend WithEvents Label167 As System.Windows.Forms.Label
    Friend WithEvents Label168 As System.Windows.Forms.Label
    Friend WithEvents Label169 As System.Windows.Forms.Label
    Friend WithEvents Label170 As System.Windows.Forms.Label
    Friend WithEvents Label171 As System.Windows.Forms.Label
    Friend WithEvents Label172 As System.Windows.Forms.Label
    Friend WithEvents Label173 As System.Windows.Forms.Label
    Friend WithEvents Label174 As System.Windows.Forms.Label
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents Label176 As System.Windows.Forms.Label
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TrackBar8 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar7 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar6 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar5 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar4 As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar3 As System.Windows.Forms.TrackBar
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TrackBar2 As System.Windows.Forms.TrackBar
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents Close_Button As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox

End Class
